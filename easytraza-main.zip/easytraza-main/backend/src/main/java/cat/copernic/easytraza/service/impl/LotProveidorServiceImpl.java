package cat.copernic.easytraza.service.impl;

import cat.copernic.easytraza.entities.LotProveidor;
import cat.copernic.easytraza.entities.Usuari;
import cat.copernic.easytraza.enums.EstatLot;
import cat.copernic.easytraza.repository.LotProveidorRepository;
import cat.copernic.easytraza.repository.UsuariRepository;
import cat.copernic.easytraza.service.LotProveidorService;
import java.time.LocalDate;
import java.time.LocalDateTime;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.util.List;
import java.util.Optional;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;

/**
 *
 * @author orjon
 */
@Service
public class LotProveidorServiceImpl implements LotProveidorService {

    private final LotProveidorRepository lotRepo;
    private final UsuariRepository usuarirepo;
    /**
     * Executa l'operació LotProveidorServiceImpl.
     * @param lotRepo
     * @param usuarirepo
     */

    public LotProveidorServiceImpl(LotProveidorRepository lotRepo, UsuariRepository usuarirepo) {
        this.lotRepo = lotRepo;
        this.usuarirepo = usuarirepo;
    }
    /**
     * Consulta dades i retorna la informació necessària per a la vista o l'API.
     * @return 
     */

    @Override
    public List<LotProveidor> findAll() {
        return lotRepo.findAll();
    }
    /**
     * Consulta dades i retorna la informació necessària per a la vista o l'API.
     * @param id
     * @return 
     */

    @Override
    public LotProveidor findById(Long id) {
        return lotRepo.findById(id)
                .orElseThrow(() -> new RuntimeException("El lot no existeix"));
    }
    /**
     * Inicia o obre l'element indicat segons el flux de treball.
     * @param lotId
     * @param confirmarTancarAnterior
     */

    @Override
    @Transactional
    public void iniciarLot(Long lotId, boolean confirmarTancarAnterior) {
        LotProveidor lot = lotRepo.findById(lotId)
                .orElseThrow(() -> new RuntimeException("El lot no existeix"));

        if (lot.getMateriaPrimera() == null || lot.getMateriaPrimera().getId() == null) {
            throw new RuntimeException("El lot no té matèria primera associada");
        }

        Optional<LotProveidor> lotObertAnterior = lotRepo.findByMateriaPrimeraIdAndEstat(
                lot.getMateriaPrimera().getId(),
                EstatLot.OBERT
        );

        if (lotObertAnterior.isPresent()
                && !lotObertAnterior.get().getId().equals(lot.getId())
                && !confirmarTancarAnterior) {
            throw new RuntimeException("Ja hi ha un lot obert d'aquesta matèria primera. Cal confirmar que vols finalitzar-lo.");
        }

        if (lotObertAnterior.isPresent()
                && !lotObertAnterior.get().getId().equals(lot.getId())) {
            LotProveidor anterior = lotObertAnterior.get();
            anterior.setEstat(EstatLot.ACABAT);
            anterior.setDataAcabament(LocalDateTime.now());
            lotRepo.save(anterior);
        }

        lot.setEstat(EstatLot.OBERT);
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        String email = auth.getName();

        Usuari usuari = usuarirepo.findByEmail(email)
                .orElseThrow(() -> new RuntimeException("Usuari no trobat"));
        lot.setUsuariObertura(usuari);
        lot.setDataObertura(LocalDateTime.now());

        lotRepo.save(lot);
    }
    /**
     * Consulta dades i retorna la informació necessària per a la vista o l'API.
     * @param estat
     * @return 
     */

    @Override
    public List<LotProveidor> findByEstat(String estat) {
        if (estat == null || estat.isBlank()) {
            return lotRepo.findAll();
        }

        return lotRepo.findByEstat(EstatLot.valueOf(estat));
    }
    /**
     * Finalitza o tanca l'element indicat segons el flux de treball.
     * @param id
     */

    @Transactional
    @Override
    public void finalitzarLot(Long id) {
        LotProveidor lot = lotRepo.findById(id)
                .orElseThrow(() -> new RuntimeException("El lot no existeix"));

        if (lot.getEstat() != EstatLot.OBERT) {
            throw new RuntimeException("Només es pot finalitzar un lot que està OBERT");
        }

        lot.setEstat(EstatLot.ACABAT);
        lot.setDataAcabament(LocalDateTime.now());

        lotRepo.save(lot);
    }
    /**
     * Executa l'operació filtrarLots.
     * @param identificador
     * @param estat
     * @param materiaId
     * @param data
     * @return 
     */

    @Override
    public List<LotProveidor> filtrarLots(String identificador, String estat, Long materiaId, LocalDate data) {

        EstatLot estatEnum = null;

        if (estat != null && !estat.isBlank()) {
            estatEnum = EstatLot.valueOf(estat);
        }

        return lotRepo.filtrarLots(
                identificador != null && !identificador.isBlank() ? identificador : null,
                estatEnum,
                materiaId,
                data
        );
    }
    /**
     * Inicia o obre l'element indicat segons el flux de treball.
     * @param lotId
     * @param confirmarTancarAnterior
     * @param usuariId
     */

    @Override
    @Transactional
    public void iniciarLotMobile(Long lotId, boolean confirmarTancarAnterior, Long usuariId) {
        LotProveidor lot = lotRepo.findById(lotId)
                .orElseThrow(() -> new RuntimeException("El lot no existeix"));

        Optional<LotProveidor> lotObertAnterior = lotRepo.findByMateriaPrimeraIdAndEstat(
                lot.getMateriaPrimera().getId(),
                EstatLot.OBERT
        );

        if (lotObertAnterior.isPresent()
                && !lotObertAnterior.get().getId().equals(lot.getId())
                && !confirmarTancarAnterior) {
            throw new RuntimeException("Ja hi ha un lot obert d'aquesta matèria primera. Cal confirmar que vols finalitzar-lo.");
        }

        if (lotObertAnterior.isPresent()
                && !lotObertAnterior.get().getId().equals(lot.getId())) {
            LotProveidor anterior = lotObertAnterior.get();
            anterior.setEstat(EstatLot.ACABAT);
            anterior.setDataAcabament(LocalDateTime.now());
            lotRepo.save(anterior);
        }

        Usuari usuari = usuarirepo.findById(usuariId)
                .orElseThrow(() -> new RuntimeException("Usuari no trobat"));

        lot.setEstat(EstatLot.OBERT);
        lot.setUsuariObertura(usuari);
        lot.setDataObertura(LocalDateTime.now());

        lotRepo.save(lot);
    }

}
