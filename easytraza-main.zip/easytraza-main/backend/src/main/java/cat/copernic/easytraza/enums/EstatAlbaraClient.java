/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Enum.java to edit this template
 */
package cat.copernic.easytraza.enums;

/**
 *
 * @author orjon
 */
public enum EstatAlbaraClient {
    PENDENT,
    LLIURAT
}
