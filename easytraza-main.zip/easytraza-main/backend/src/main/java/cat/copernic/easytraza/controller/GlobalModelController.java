package cat.copernic.easytraza.controller;

import cat.copernic.easytraza.entities.Usuari;
import cat.copernic.easytraza.repository.UsuariRepository;
import java.security.Principal;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ModelAttribute;

/**
 *
 * @author orjon Añade datos globales disponibles en todas las vistas Thymeleaf.
 */
@ControllerAdvice
public class GlobalModelController {

    private final UsuariRepository usuariRepository;
    /**
     * Executa l'operació GlobalModelController.
     * @param usuariRepository
     */

    public GlobalModelController(UsuariRepository usuariRepository) {
        this.usuariRepository = usuariRepository;
    }
    /**
     * Executa l'operació usuariSessio.
     * @param principal
     * @return 
     */

    @ModelAttribute("usuariSessio")
    public Usuari usuariSessio(Principal principal) {
        if (principal == null) {
            return null;
        }

        return usuariRepository.findByEmail(principal.getName())
                .orElse(null);
    }
}
